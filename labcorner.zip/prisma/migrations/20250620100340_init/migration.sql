-- AlterTable
ALTER TABLE `tugas` ADD COLUMN `tutup_penugasan` BOOLEAN NOT NULL DEFAULT false;
