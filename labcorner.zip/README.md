"# Awal baru" 
